export interface CreateTodoRequest {
  name: string
  dueDate: string
}
